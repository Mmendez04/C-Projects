﻿using System;

class PizzaSlicesCalculator
{
    static void Main()
    {
        // Step A
        Console.Write("Enter the radius of the pizza in inches: ");
        double radius = Convert.ToDouble(Console.ReadLine());

        // Step B
        double area = Math.PI * Math.Pow(radius, 2);
        int numberOfSlices = (int)(area / 14.125);

        // Step C
        Console.WriteLine($"Number of slices: {numberOfSlices}");
    }
}

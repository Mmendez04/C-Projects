using System;
using System.IO;
using System.Runtime.CompilerServices;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Work_4
{
    public partial class Form1 : Form
    {
        private int randomNumber;
        private int tries = 10;
        private int hints = 3;
        private int hintCount = 0;
        private bool hintsEnabled = false;




        public Form1()
        {
            InitializeComponent();
            Guessnumber_button.Click += new EventHandler(this.Guessnumber_button_Click);
            randomNumber = new Random().Next(1, 101);
        }

        private void Guessnumber_button_Click(object sender, EventArgs e)
        {
            if (int.TryParse(Guess_textBox.Text, out int guess))
            {
                if (guess == 0 && tries > 2 && hints > 0)
                {
                    MessageBox.Show("About to give a�hint");
                    GiveHint();
                    tries -= 2;
                    hints--;
                }
                else if (guess >= 1 && guess <= 100)
                {
                    CheckGuess(guess);
                    tries--;
                    File.AppendAllText("Guesses.txt", guess + "\n");
                }
                else
                {
                    MessageBox.Show("Invalid input. Please enter a number between 1 and 100.");
                }
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter a number.");
            }

            if (tries == 0)
            {
                MessageBox.Show("You lost! The number was " + randomNumber);
            }

            Trials_textBox.Text = tries.ToString();
            
        }

        private void CheckGuess(int guess)
        {
            if (guess < randomNumber)
            {
                Guessfeedback_textBox.Text = "The number is bigger than your guess.";
            }
            else if (guess > randomNumber)
            {
                Guessfeedback_textBox.Text = "The number is smaller than your guess.";
            }
            else
            {
                MessageBox.Show("Congratulations! You guessed the number.");
                Application.Exit();
            }
        }

        private void GiveHint()
        {
            MessageBox.Show("Inside GiveHint method");
            

            string hintMessage = "";

            int hintType = new Random().Next(1, 6);
            switch (hintType)
            {
                case 1:
                    hintMessage = $"The number is bigger than or equal to the square of {Math.Floor(Math.Sqrt(randomNumber))}";
                    break;
                case 2:
                    hintMessage = $"The number is smaller than or equal to the square of {Math.Ceiling(Math.Sqrt(randomNumber))}";
                    break;
                case 3:
                    hintMessage = $"The number is a multiple of {randomNumber % new Random().Next(2, randomNumber)}";
                    break;
                case 4:
                    hintMessage = $"The number is {(randomNumber % 2 == 0 ? "even" : "odd")}";
                    break;
                default:
                    hintMessage = $"The number has {(randomNumber < 10 ? "one" : "two")} digit(s)";
                    break;
            }
            listBox1.Items.Add(hintMessage);
            MessageBox.Show("Generated Hint: " + hintMessage);
            MessageBox.Show("Total hints in ListBox: " + listBox1.Items.Count);
        }
        

        private void Quit_button_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
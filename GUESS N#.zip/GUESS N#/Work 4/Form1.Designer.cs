﻿namespace Work_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Guessnumber_button = new Button();
            Quit_button = new Button();
            labelHint = new Label();
            label2 = new Label();
            Guess_label = new Label();
            Trials_label = new Label();
            Guessfeedback_label = new Label();
            Guess_textBox = new TextBox();
            Trials_textBox = new TextBox();
            Guessfeedback_textBox = new TextBox();
            listBox1 = new ListBox();
            SuspendLayout();
            // 
            // Guessnumber_button
            // 
            Guessnumber_button.Location = new Point(330, 1064);
            Guessnumber_button.Name = "Guessnumber_button";
            Guessnumber_button.Size = new Size(198, 127);
            Guessnumber_button.TabIndex = 0;
            Guessnumber_button.Text = "Guess a number";
            Guessnumber_button.UseVisualStyleBackColor = true;
            // 
            // Quit_button
            // 
            Quit_button.Location = new Point(1000, 1076);
            Quit_button.Name = "Quit_button";
            Quit_button.Size = new Size(188, 115);
            Quit_button.TabIndex = 1;
            Quit_button.Text = "Quit";
            Quit_button.UseVisualStyleBackColor = true;
            Quit_button.Click += Quit_button_Click;
            // 
            // labelHint
            // 
            labelHint.AutoSize = true;
            labelHint.Location = new Point(1117, 102);
            labelHint.Name = "labelHint";
            labelHint.Size = new Size(304, 48);
            labelHint.TabIndex = 2;
            labelHint.Text = "Hints given so far:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(157, 190);
            label2.Name = "label2";
            label2.RightToLeft = RightToLeft.No;
            label2.Size = new Size(731, 192);
            label2.TabIndex = 3;
            label2.Text = "Welcome to my Guessing game. You have 10\r\ntrials to guess a number between 1 and 100.\r\nYou can ask for hints, each hint costs 2 trials.\r\nEnjoy my game!";
            // 
            // Guess_label
            // 
            Guess_label.AutoSize = true;
            Guess_label.Location = new Point(157, 467);
            Guess_label.Name = "Guess_label";
            Guess_label.Size = new Size(283, 48);
            Guess_label.TabIndex = 4;
            Guess_label.Text = "Enter your guess";
            // 
            // Trials_label
            // 
            Trials_label.AutoSize = true;
            Trials_label.Location = new Point(157, 613);
            Trials_label.Name = "Trials_label";
            Trials_label.Size = new Size(340, 48);
            Trials_label.TabIndex = 5;
            Trials_label.Text = "Number of trials left";
            // 
            // Guessfeedback_label
            // 
            Guessfeedback_label.AutoSize = true;
            Guessfeedback_label.Location = new Point(157, 766);
            Guessfeedback_label.Name = "Guessfeedback_label";
            Guessfeedback_label.Size = new Size(268, 48);
            Guessfeedback_label.TabIndex = 6;
            Guessfeedback_label.Text = "Guess feedback";
            // 
            // Guess_textBox
            // 
            Guess_textBox.Location = new Point(600, 467);
            Guess_textBox.Name = "Guess_textBox";
            Guess_textBox.Size = new Size(300, 55);
            Guess_textBox.TabIndex = 7;
            // 
            // Trials_textBox
            // 
            Trials_textBox.Location = new Point(600, 624);
            Trials_textBox.Name = "Trials_textBox";
            Trials_textBox.Size = new Size(300, 55);
            Trials_textBox.TabIndex = 8;
            // 
            // Guessfeedback_textBox
            // 
            Guessfeedback_textBox.Location = new Point(600, 766);
            Guessfeedback_textBox.Name = "Guessfeedback_textBox";
            Guessfeedback_textBox.Size = new Size(300, 55);
            Guessfeedback_textBox.TabIndex = 9;
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 48;
            listBox1.Location = new Point(1039, 190);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(604, 820);
            listBox1.TabIndex = 10;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(20F, 48F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1699, 1241);
            Controls.Add(listBox1);
            Controls.Add(Guessfeedback_textBox);
            Controls.Add(Trials_textBox);
            Controls.Add(Guess_textBox);
            Controls.Add(Guessfeedback_label);
            Controls.Add(Trials_label);
            Controls.Add(Guess_label);
            Controls.Add(label2);
            Controls.Add(labelHint);
            Controls.Add(Quit_button);
            Controls.Add(Guessnumber_button);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Guessnumber_button;
        private Button Quit_button;
        private Label labelHint;
        private Label label2;
        private Label Guess_label;
        private Label Trials_label;
        private Label Guessfeedback_label;
        private TextBox Guess_textBox;
        private TextBox Trials_textBox;
        private TextBox Guessfeedback_textBox;
        private ListBox listBox1;
    }
}
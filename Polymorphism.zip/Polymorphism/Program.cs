﻿using System.Diagnostics.Metrics;

class Program
{
    static void Main(string[] args)
    {
        var basket = new Basket(20, 15, 25); // Example limits

        while (true)
        {
            Console.WriteLine("\nChoose an item to add:");
            Console.WriteLine("1. Chocolate Egg");
            Console.WriteLine("2. Chocolate Bunny");
            Console.WriteLine("3. Pack of Crackers");
            Console.WriteLine("4. Water");
            Console.WriteLine("5. Hard Candy");
            Console.WriteLine("6. Soda Can");
            Console.WriteLine("0. Exit");
            Console.Write("Your choice: ");
            string input = Console.ReadLine();

            if (input == "0") // Check if input string is "0" to exit
            {
                break;
            }

            if (!int.TryParse(input, out int choice) || choice < 0 || choice > 6)
            {
                Console.WriteLine("Invalid choice. Please enter a number between 0 and 6.");
                continue; // Continue to the next iteration of the loop if input is invalid
            }

            EasterGoodies item = choice switch
            {
                1 => new ChocolateEgg(),
                2 => new ChocolateBunny(),
                3 => new PackOfCrackers(),
                4 => new Water(),
                5 => new HardCandy(),
                6 => new SodaCan(),
                _ => null
            };

            if (item != null && basket.Add(item))
            {
                Console.WriteLine($"Item added successfully: {item.DisplayDetails()}");
            }
            else
            {
                Console.WriteLine("Failed to add item. It might exceed the basket's limits.");
            }

            Console.WriteLine($"Basket now contains {basket.CurrentItemCount} items. Weight: {basket.CurrentWeight}, Volume: {basket.CurrentVolume}.");
        }
    }
}

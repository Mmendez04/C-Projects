﻿using System;
using System.Collections.Generic;
using System.Linq;

public abstract class EasterGoodies
{
    public double Weight { get; }
    public double Volume { get; }

    protected EasterGoodies(double weight, double volume)
    {
        Weight = weight;
        Volume = volume;
    }

    // Abstract method to display item details
    public abstract string DisplayDetails();
}

public class ChocolateEgg : EasterGoodies
{
    public ChocolateEgg() : base(0.1, 0.5) { }
    public override string DisplayDetails() => "Chocolate Egg - Light and small, perfect for the hunt!";
}

public class ChocolateBunny : EasterGoodies
{
    public ChocolateBunny() : base(1, 2) { }
    public override string DisplayDetails() => "Chocolate Bunny - A delightful treat for Easter morning!";
}

public class PackOfCrackers : EasterGoodies
{
    public PackOfCrackers() : base(0.5, 2.5) { }
    public override string DisplayDetails() => "Pack of Crackers - Great for sharing!";
}

public class Water : EasterGoodies
{
    public Water() : base(2, 3) { }
    public override string DisplayDetails() => "Bottle of Water - Essential for staying hydrated.";
}

public class HardCandy : EasterGoodies
{
    public HardCandy() : base(0.6, 0.5) { }
    public override string DisplayDetails() => "Hard Candy - Sweet and flavorful, a classic choice!";
}

public class SodaCan : EasterGoodies
{
    public SodaCan() : base(2.5, 3.5) { }
    public override string DisplayDetails() => "Soda Can - A refreshing carbonated drink.";
}

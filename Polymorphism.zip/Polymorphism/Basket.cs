﻿public class Basket
{
    private List<EasterGoodies> items = new List<EasterGoodies>();
    public int MaxItemCount { get; }
    public double MaxWeight { get; }
    public double MaxVolume { get; }

    public int CurrentItemCount => items.Count;
    public double CurrentWeight => items.Sum(i => i.Weight);
    public double CurrentVolume => items.Sum(i => i.Volume);

    public Basket(int maxItemCount, double maxWeight, double maxVolume)
    {
        MaxItemCount = maxItemCount;
        MaxWeight = maxWeight;
        MaxVolume = maxVolume;
    }

    public bool Add(EasterGoodies item)
    {
        if (CurrentItemCount < MaxItemCount && CurrentWeight + item.Weight <= MaxWeight && CurrentVolume + item.Volume <= MaxVolume)
        {
            items.Add(item);
            return true;
        }
        return false;
    }
}


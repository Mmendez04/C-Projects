﻿using System;

class StudentFinalGradeCalculator
{
    static void Main()
    {
        // Step A
        Console.Write("Enter Assignment 1 grade (out of 100): ");
        double assignment1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter Assignment 2 grade (out of 100): ");
        double assignment2 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter Exam 1 grade (out of 100): ");
        double exam1 = Convert.ToDouble(Console.ReadLine());

        Console.Write("Enter Exam 2 grade (out of 100): ");
        double exam2 = Convert.ToDouble(Console.ReadLine());

        // Step B
        double avgAssignments = (assignment1 + assignment2) / 2;

        // Step C
        double avgExams = (exam1 + exam2) / 2;

        // Step D
        double finalGrade = (avgAssignments * 0.4) + (avgExams * 0.6);

        // Step E
        Console.WriteLine($"Final Grade: {finalGrade}");
    }
}

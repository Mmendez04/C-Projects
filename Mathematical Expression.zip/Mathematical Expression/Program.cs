﻿using System;

public class Program
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Please enter an arithmetic expression that consists of numbers, %, +, -, /, and *:");
        string expression = Console.ReadLine();
        double result = EvaluateExpression(expression);
        Console.WriteLine("The result of your expression is: " + result);
    }

    public static double EvaluateExpression(string expression)
    {
        char[] operators = { '+', '-', '*', '/', '%' };

        string[] elements = expression.Split(operators, StringSplitOptions.RemoveEmptyEntries);

        double result = double.Parse(elements[0]);

        int operatorIndex = 0;

        for (int i = 1; i < expression.Length; i++)
        {
            if (Array.IndexOf(operators, expression[i]) != -1)
            {
                char operation = expression[i];
                double operand = double.Parse(elements[operatorIndex + 1]);
                operatorIndex++;

                switch (operation)
                {
                    case '+':
                        result += operand;
                        break;
                    case '-':
                        result -= operand;
                        break;
                    case '*':
                        result *= operand;
                        break;
                    case '/':
                        result /= operand;
                        break;
                    case '%':
                        result %= operand;
                        break;
                }
            }
        }

        return result;
    }
}

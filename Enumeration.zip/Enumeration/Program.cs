﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Create a new kite!");

        Kite kite = CreateKite();
        float cost = kite.GetCost();

        Console.WriteLine($"\nThe cost of the kite is: ${cost:F2}");
    }

    static Kite CreateKite()
    {
        Kite kite = new Kite();

        kite.Sail = GetUserSelection<KiteSail>("Select Kite Sail");
        kite.Spine = GetUserSelection<Spine>("Select Spine");
        kite.CrossSpar = GetUserSelection<CrossSpar>("Select Cross Spar");
        kite.Bridle = GetUserSelection<Bridle>("Select Bridle");
        kite.Line = GetUserSelection<Line>("Select Line");
        kite.KiteTail = GetUserSelection<KiteTail>("Select Kite Tail");

        return kite;
    }

    static T GetUserSelection<T>(string prompt) where T : Enum
    {
        Console.WriteLine($"\n{prompt}:");
        foreach (T value in Enum.GetValues(typeof(T)))
        {
            Console.WriteLine($"{(int)(object)value}. {value}");
        }

        int selection;
        while (!int.TryParse(Console.ReadLine(), out selection) ||
               !Enum.IsDefined(typeof(T), selection))
        {
            Console.WriteLine("Invalid selection. Please try again.");
        }

        return (T)(object)selection;
    }
}

class Kite
{
    public KiteSail Sail { get; set; }
    public Spine Spine { get; set; }
    public CrossSpar CrossSpar { get; set; }
    public Bridle Bridle { get; set; }
    public Line Line { get; set; }
    public KiteTail KiteTail { get; set; }

    public float GetCost()
    {
        float cost = 0;

        cost += GetPartCost(Sail);
        cost += GetPartCost(Spine);
        cost += GetPartCost(CrossSpar);
        cost += GetPartCost(Bridle);
        cost += GetPartCost(Line);
        cost += GetPartCost(KiteTail);

        return cost;
    }

    private float GetPartCost(Enum part)
    {
        switch (part)
        {
            case KiteSail.Tyvek:
                return 25.50f;
            case KiteSail.Mylar:
                return 27.00f;
            case KiteSail.RipStopNylon:
                return 33.55f;
            case Spine.Maple:
                return 12.55f;
            case Spine.BirchSpars:
                return 15.00f;
            case Spine.FiberGlass:
            case Spine.CarbonSpars:
                return 30.00f;
            case CrossSpar.Maple:
                return 11.55f;
            case CrossSpar.BirchSpars:
                return 14.00f;
            case CrossSpar.FiberGlass:
                return 28.00f;
            case CrossSpar.CarbonSpars:
                return 27.00f;
            case Bridle.SinglePoint:
                return 20.00f;
            case Bridle.TwoPoints:
                return 25.50f;
            case Bridle.ThreePoints:
                return 35.00f;
            case Line.Cotton:
                return 10.00f;
            case Line.TwistedNylon:
                return 15.00f;
            case KiteTail.Plastic:
                return 12.00f;
            case KiteTail.RipStopNylon:
                return 45.00f;
            default:
                return 0;
        }
    }
}

enum KiteSail
{
    Tyvek = 1,
    Mylar,
    RipStopNylon
}

enum Spine
{
    Maple = 1,
    BirchSpars,
    FiberGlass,
    CarbonSpars
}

enum CrossSpar
{
    Maple = 1,
    BirchSpars,
    FiberGlass,
    CarbonSpars
}

enum Bridle
{
    SinglePoint = 1,
    TwoPoints,
    ThreePoints
}

enum Line
{
    Cotton = 1,
    TwistedNylon
}

enum KiteTail
{
    Plastic = 1,
    RipStopNylon
}

